export class MenuItem {
    url: string;
    nombre: string;
}
